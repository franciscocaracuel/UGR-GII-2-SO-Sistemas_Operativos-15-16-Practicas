////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º B - Ingeniería Informática - 2015/2016
//
// --
//
// Ejercicio02. Sesión 6. Módulo 2
//

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h> // O_RDONLY
#include <unistd.h> // execl

/*
 * 
 */
int main(int argc, char** argv) {

    // Se comprueba que los parámetros sean correctos
    if (argc != 4) {
        printf("\nDebes introducir 3 parámetros. Sintaxis: orden | fichero\n");
        perror("\nError. Cantidad de parámetros incorrecta.\n");
        exit(1);
    }

    if (strcmp(argv[2], "|") != 0) {
        printf("\nEl segundo parámetro debe ser |. Sintaxis: orden | fichero\n");
        perror("\nError. Redireccionamiento incorrecto.\n");
        exit(2);
    }

    // Se comprueba si el fichero existe
    int fd;


    if ((fd = open(".tempEjercicio02", O_CREAT | O_RDWR | O_TRUNC, 0644)) < 0) {
        printf("\nNo se puede abrir el fichero %s para escritura. Sintaxis: orden | fichero\n", argv[3]);
        perror("\nError. Fichero inexistente.\n");
        exit(3);
    }


    // Se cierra la salida estándar
    close(STDOUT_FILENO);


    // Se duplica el descriptor
    if (fcntl(fd, F_DUPFD, STDOUT_FILENO) == -1) {
        printf("\nNo se puede duplicar el descriptor en la salida estándar\n");
        perror("\nError al duplicar el descriptor.\n");
        exit(5);
    }

    // Se cierra la entrada estándar
    close(STDIN_FILENO);

    if (fcntl(fd, F_DUPFD, STDIN_FILENO) == -1) {
        printf("\nNo se puede duplicar el descriptor en la entrada estándar\n");
        perror("\nError al duplicar el descriptor.\n");
        exit(5);
    }

    close(fd);

    if (execlp(argv[1], argv[1], NULL) < 0) {
        printf("\nerror\n");
        perror("\nError al ejecutar la orden.\n");
        exit(6);
    }

    if (execlp(argv[3], argv[3], NULL) < 0) {
        printf("\nerror\n");
        perror("\nError al ejecutar la orden.\n");
        exit(7);
    }

    return (EXIT_SUCCESS);

}

