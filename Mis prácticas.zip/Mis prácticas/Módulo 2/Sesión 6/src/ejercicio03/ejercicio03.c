////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º B - Ingeniería Informática - 2015/2016
//
// --
//
// Ejercicio03. Sesión 6. Módulo 2
//

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

/*
 * 
 */
int main(int argc, char** argv) {
    
    // Se comprueba que los parámetros sean correctos
    if (argc != 3) {
        printf("\nDebes introducir 2 ficheros. Sintaxis: fichero1 fichero2\n");
        perror("\nError. Cantidad de parámetros incorrecta.\n");
        exit(1);
    }

    // Se declaran los cerrojos que se van a utilizar.
    // cerrojo1 y cerrojo3 los usará el proceso hijo
    // cerrojo2 y cerrojo4 los usará el proceso padre
    struct flock cerrojo1;
    struct flock cerrojo2;
    struct flock cerrojo3;
    struct flock cerrojo4;
    
    // Los descriptores de los archivos
    // fd1 y fd4 corresponderán al archivo que recibe como primer parámetro
    // fd2 y fd3 corresponderán al archivo recibe como segundo parámetro
    int fd1, fd2, fd3, fd4;

    // Se bloquean los ficheros completos con los cerrojos
    cerrojo1.l_type = F_WRLCK;
    cerrojo1.l_whence = SEEK_SET;
    cerrojo1.l_start = 0;
    cerrojo1.l_len = 0;

    cerrojo2.l_type = F_WRLCK;
    cerrojo2.l_whence = SEEK_SET;
    cerrojo2.l_start = 0;
    cerrojo2.l_len = 0;

    cerrojo3.l_type = F_WRLCK;
    cerrojo3.l_whence = SEEK_SET;
    cerrojo3.l_start = 0;
    cerrojo3.l_len = 0;

    cerrojo4.l_type = F_WRLCK;
    cerrojo4.l_whence = SEEK_SET;
    cerrojo4.l_start = 0;
    cerrojo4.l_len = 0;

    // Se guardará el pid del hijo
    pid_t pid;

    // Se ha producido un error al lanzar al proceso hijo
    if ((pid = fork()) < 0) {

        printf("\nSe ha producido un error al crear el proceso hijo\n\n");
        perror("Error lanzando el proceso hijo");
        exit(-2);

    // Código ejecutado por el proceso hijo
    } else if (pid == 0) {
        
        printf("\n\nHijo 1\n\n");

        // Se abre el fichero que recibe por parámetro
        if ((fd1 = open(argv[1], O_WRONLY)) == -1) {
            perror("open fallo");
        }

        // Se establece un cerrojo al fichero que recibe por el primer argumento
        // Como no tiene ningún cerrojo no debe dar error
        if (fcntl(fd1, F_SETLKW, &cerrojo1) == -1) {
            
            printf("\n\nhijo: ERROR PRIMER CERROJO DEL hijo");

            if (fcntl(fd1, F_SETLKW, &cerrojo1) == -1 && cerrojo1.l_type != F_UNLCK) {
                printf("\n\nhijo: PRIMER CERROJO DEL hijo BLOQUEADO por %d", cerrojo1.l_pid);
            }

        } else {
            printf("\n\nhijo: SE PONE EL PRIMER CERROJO\n\n");
        }

        // Se duerme el proceso para dar tiempo a que el padre ponga el cerrojo
        // al otro archivo y así se dé un estado de bloqueo con F_SETLKW
        sleep(5);

        printf("\n\nhijo 2\n\n");

        // Se abre el fichero que recibe por el segundo parámetro
        if ((fd3 = open(argv[2], O_WRONLY)) == -1) {
            perror("hijo: FALLA ABRIR EL FICHERO SEGUNDO");
        } else {
            printf("\nhijo: SE ABRE EL SEGUNDO FICHERO");
        }

        printf("\n\nhijo 3\n\n");

        // Se establece un cerrojo al archivo que recibe por segundo parámetro
        // Como el proceso padre ya habrá puesto su cerrojo en este archivo, debe
        // dar error.
        // Ahora depende de si el proceso padre ha llegado a esta parte pero
        // en su código. En el caso de que haya llegado se produciría un 
        // interbloqueo, pero se puede ver como la ejecución del programa
        // continua. Esto se debe a que el kernel comprueba si se va a dar
        // el interbloqueo y lo previene, liberando uno de los dos.
        if (fcntl(fd3, F_SETLKW, &cerrojo3) == -1) {
            printf("\n\nhijo: ERROR PONIENDO EL SEGUNDO CERROJO\n");

            if (fcntl(fd3, F_SETLKW, &cerrojo3) == -1 && cerrojo3.l_type != F_UNLCK) {
                printf("\n\nhijo: SEGUNDO CERROJO DEL hijo BLOQUEADO por %d", cerrojo3.l_pid);
            }

            if (cerrojo3.l_type == EDEADLK) {
                printf("\n\nPADRE: ERROR EDEADLK\n\n");
            }

        } else {
            printf("\n\nhijo 4\n\n");
            printf("\nhijo: SE PONE EL SEGUNDO CERROJO\n");
        }

        sleep(5);

        printf("\n\nhijo 5\n\n");

        // Se ponen los cerrojos de modo que se libere el archivo
        // Esto provoca que el proceso que el kernel ha dejado pasar en el
        // interbloqueo libere los dos archivos y el otro proceso si puede 
        // establecer un segundo cerrojo al archivo (porque realmente no existe)
        cerrojo1.l_type = F_UNLCK;
        cerrojo1.l_whence = SEEK_SET;
        cerrojo1.l_start = 0;
        cerrojo1.l_len = 0;

        cerrojo3.l_type = F_UNLCK;
        cerrojo3.l_whence = SEEK_SET;
        cerrojo3.l_start = 0;
        cerrojo3.l_len = 0;

        printf("\n\nhijo: cerrando el fichero\n");

        // Se le quita el cerrojo al archivo
        if (fcntl(fd1, F_SETLKW, &cerrojo1) == -1) perror("Desbloqueo");
        if (fcntl(fd3, F_SETLKW, &cerrojo3) == -1) perror("Desbloqueo");

        // Se cierran los archivos abiertos
        close(fd1);
        close(fd3);
        
    // Código ejecutado por él mismo
    } else {

        printf("\n\nPADRE 1\n\n");

        // Se abre el fichero que recibe por parámetro
        if ((fd2 = open(argv[2], O_WRONLY)) == -1) {
            perror("open fallo");
        }

        // Se establece un cerrojo al fichero que recibe por el segundo argumento
        // Como no tiene ningún cerrojo no debe dar error
        if (fcntl(fd2, F_SETLKW, &cerrojo2) == -1) {
            printf("\n\nPADRE: ERROR PRIMER CERROJO DEL PADRE");

            if (fcntl(fd2, F_SETLKW, &cerrojo2) == -1 && cerrojo2.l_type != F_UNLCK) {
                printf("\n\nPADRE: PRIMER CERROJO DEL PADRE BLOQUEADO por %d", cerrojo2.l_pid);
            }

        } else {
            printf("\n\nPADRE: SE PONE EL PRIMER CERROJO\n\n");
        }

        // Se duerme el proceso para dar tiempo a que el hijo ponga el cerrojo
        // al otro archivo y así se dé un estado de bloqueo con F_SETLKW
        sleep(5);

        printf("\n\nPADRE 2\n\n");

        // Se abre el fichero que recibe por parámetro
        if ((fd4 = open(argv[1], O_WRONLY)) == -1) {
            perror("PADRE: FALLA ABRIR EL FICHERO SEGUNDO");
        } else {
            printf("\nPADRE: SE ABRE EL SEGUNDO FICHERO");
        }

        printf("\n\nPADRE 3\n\n");

        // Se establece un cerrojo al archivo que recibe por primer parámetro
        // Como el proceso hijo ya habrá puesto su cerrojo en este archivo, debe
        // dar error.
        // Ahora depende de si el proceso hijo ha llegado a esta parte pero
        // en su código. En el caso de que haya llegado se produciría un 
        // interbloqueo, pero se puede ver como la ejecución del programa
        // continua. Esto se debe a que el kernel comprueba si se va a dar
        // el interbloqueo y lo previene, liberando uno de los dos.
        if (fcntl(fd4, F_SETLKW, &cerrojo4) == -1) {
            printf("\n\nPADRE: ERROR PONIENDO EL SEGUNDO CERROJO\n");

            if (fcntl(fd4, F_SETLKW, &cerrojo4) == -1 && cerrojo4.l_type != F_UNLCK) {
                printf("\n\nPADRE: SEGUNDO CERROJO DEL PADRE BLOQUEADO por %d", cerrojo4.l_pid);
            }

            if (cerrojo4.l_type == EDEADLK) {
                printf("\n\nPADRE: ERROR EDEADLK\n\n");
            }

        } else {
            printf("\n\nPADRE 4\n\n");
            printf("\nPADRE: SE PONE EL SEGUNDO CERROJO\n");
        }

        sleep(5);

        printf("\n\nPADRE 5\n\n");

        // Se ponen los cerrojos de modo que se libere el archivo
        // Esto provoca que el proceso que el kernel ha dejado pasar en el
        // interbloqueo libere los dos archivos y el otro proceso si puede 
        // establecer un segundo cerrojo al archivo (porque realmente no existe)
        cerrojo2.l_type = F_UNLCK;
        cerrojo2.l_whence = SEEK_SET;
        cerrojo2.l_start = 0;
        cerrojo2.l_len = 0;

        cerrojo4.l_type = F_UNLCK;
        cerrojo4.l_whence = SEEK_SET;
        cerrojo4.l_start = 0;
        cerrojo4.l_len = 0;

        printf("\n\nPadre: cerrando el fichero\n");

        // Se le quita el cerrojo al archivo
        if (fcntl(fd2, F_SETLKW, &cerrojo2) == -1) perror("Desbloqueo");
        if (fcntl(fd4, F_SETLKW, &cerrojo4) == -1) perror("Desbloqueo");

        // Se cierran los dos archivos
        close(fd2);
        close(fd4);

        // Se espera al proceso hijo para que no quede en modo zombie
        wait(pid);

    }

    return (EXIT_SUCCESS);

}