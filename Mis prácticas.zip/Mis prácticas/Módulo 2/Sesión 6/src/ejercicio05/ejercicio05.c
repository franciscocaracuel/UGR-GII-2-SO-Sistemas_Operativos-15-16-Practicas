////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º B - Ingeniería Informática - 2015/2016
//
// --
//
// Ejercicio05. Sesión 6. Módulo 2
//

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h> // O_CREAT, etc
#include <sys/stat.h> // fstat
#include <sys/mman.h> // mmap
#include <string.h> // memcpy

/*
 * 
 */
int main(int argc, char** argv) {

    // Se comprueba que los parámetros sean correctos
    if (argc != 3) {
        printf("\nDebes introducir 2 ficheros. Sintaxis: %s fichero1 fichero2\n", argv[0]);
        perror("\nError. Cantidad de parámetros incorrecta.\n");
        exit(1);
    }

    // Descriptor del fichero
    int fd1, fd2;
    
    // Datos del fichero
    struct stat sb;
    
    char *fichero1, *fichero2;

    // Se intenta abrir el fichero para comprobar si existe
    if ((fd1 = open(argv[1], O_RDONLY)) < 0) {
        printf("\nNo se puede abrir el fichero %s para lectura. Sintaxis: orden <|> fichero\n", argv[1]);
        perror("\nError. Fichero inexistente.\n");
        exit(2);
    }
    
    // Se intenta acceder a los datos del fichero
    if(fstat(fd1, &sb) == -1){
        printf("\nError al hacer el stat");
        exit(3);
    }
    
    // Se comprueba que sea un fichero
    if(!S_ISREG(sb.st_mode)){
        printf("\n%s no es un fichero regular", argv[1]);
        exit(4);
    }
    
    // Se abre el segundo fichero
    if ((fd2 = open(argv[2], O_CREAT | O_RDWR | O_TRUNC, 0644)) < 0) {
        printf("\nNo se puede abrir el fichero %s para escritura.\n", argv[2]);
        perror("\nError. Fichero inexistente.\n");
        exit(5);
    }
    
    // Se mapea el fichero1 
    fichero1 = (char*) mmap(0, sb.st_size, PROT_READ, MAP_SHARED, fd1, 0);
    
    // Se aumenta el tamaño del fichero2
    ftruncate(fd2, sb.st_size);
    
    // Se mapea el fichero2
    fichero2 = (char*) mmap(0, sb.st_size, PROT_WRITE, MAP_SHARED, fd2, 0);
    
    if(fichero1 == MAP_FAILED){
        printf("\nFalló el mapeo de %s\n", argv[1]);
        exit(6);
    }
    
    if(fichero2 == MAP_FAILED){
        printf("\nFalló el mapeo de %s\n", argv[2]);
        exit(7);
    }
    
    // Se cierran los descriptores porque no son necesarios
    close(fd1);
    close(fd2);
    
    memcpy(fichero2, fichero1, sb.st_size);
    
    // Se cierran las proyecciones
    if(munmap(fichero1, sb.st_size) == -1){
        printf("\nError al cerra la proyección de %s\n", argv[1]);
        exit(8);
    }
    
    if(munmap(fichero2, sb.st_size) == -1){
        printf("\nError al cerra la proyección de %s\n", argv[2]);
        exit(9);
    }

    return (EXIT_SUCCESS);
    
}

