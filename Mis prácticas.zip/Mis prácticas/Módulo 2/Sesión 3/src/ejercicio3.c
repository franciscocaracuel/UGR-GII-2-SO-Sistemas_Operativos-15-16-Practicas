////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
//
// Sistemas Operativos. 2º. Curso 2015/2016
//
// Ejercicio 3. Módulo 2. Sesión 3.
////////////////////////////////////////////////////////////////////////////////

#include <stdlib.h> // Para el exit y para pid_t
#include <errno.h> // Para utilizar la salida de error
#include <sys/types.h> 
#include <unistd.h>
#include <stdio.h> // Para utilizar printf
#include <string.h>
#include <signal.h>

////////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char* argv[]){
      
    printf("\n");
    
    // Se guardará el pid del hijo
    pid_t childPid1, childPid2;
        
    int nProcs = 20;

    /*
    Jerarquía de procesos tipo 1
     */
    // Cada proceso va creando un proceso hijo y se tendría una jerarquía lineal
    // descendente, donde solo hay un proceso hijo por cada proceso padre
    for(unsigned int i=0; i<nProcs; i++) {
        
        if((childPid1 = fork()) < -1){
            
            fprintf(stderr, "Could not create child %d: %s\n", i, strerror(errno));
            exit(-1);
            
        
        }
        
        // true es distinto de 0, false es 0, por tanto, entraría en el if el padre
        if(childPid1){            
            exit(-1);
        }
            
        printf("\n%d: Proceso hijo %d, que tiene como padre a %d\n", i, getpid(), getppid());
        
    }
    
    /*
    Jerarquía de procesos tipo 2
     */
    // Existe un padre, que va creando muchos procesos hijos. Con if(!childPid)
    // se consigue que entre el proceso hijo y termine su ejecución, de este 
    // modo se tiene un padre que ha creado 20 hijos (pero realmente se queda
    // sin hijos en el momento en el que los crea)
    // El que va a ejecutar este código es el último hijo que se ha creado en el
    // for anterior.
    for(unsigned int i=0; i<nProcs; i++) {
        
        if((childPid2 = fork()) < -1){
            
            fprintf(stderr, "Could not create child %d: %s\n", i, strerror(errno));
            exit(-1);
            
        
        }
        
        // true es distinto de 0, false es 0, por tanto, entraría en el if el hijo
        if(!childPid2){
            exit(-2);          
        }
                        
        printf("\n%d: Proceso actual %d\n", i, getpid());
        
    }
    
    printf("\n\n");
    
    return (0);
    
}