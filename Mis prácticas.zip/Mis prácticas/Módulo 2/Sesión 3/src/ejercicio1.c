////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
//
// Sistemas Operativos. 2º. Curso 2015/2016
//
// Ejercicio 1. Módulo 2. Sesión 3.
////////////////////////////////////////////////////////////////////////////////

#include <stdlib.h> // Para el exit y para pid_t
#include <stdio.h> // Para utilizar printf
#include <errno.h> // Para utilizar la salida de error

////////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char* argv[]){
    
    // Necesita 1 argumento
    if(argc != 2){
        printf("\nEl programa %s necesita 1 argumento. Sintaxis: <%s número_entero>\n\n", 
                argv[0], argv[0]);
        perror("El programa necesita un argumento");
        exit (-1);
    }
    
    printf("\n");
    
    // Se guardará el pid del hijo
    pid_t pid;
    
    // Se guarda el valor del número que se recibe por parámetro
    long number = strtol(argv[1], 0, 10);
    
    // Se ha producido un error al lanzar al proceso hijo
    if((pid = fork()) < 0){
        
        printf("\nSe ha producido un error al crear el proceso hijo\n\n");
        perror("Error lanzando el proceso hijo");
        exit (-2);
        
    // Código ejecutado por el proceso hijo
    } else if(pid==0){
        
        // Comprueba si es par
        if(number%2==0)
            printf("Proceso hijo: El número %s es par.", argv[1]);
        else
            printf("Proceso hijo: El número %s es impar.", argv[1]);
        
    // Código ejecutado por el mismo
    } else{
        
        // Si el número es divisible por 4
        if(number%4==0){
            printf("Proceso padre: El número %s es divisible por 4.", argv[1]);
        } else{
            printf("Proceso padre: El número %s no es divisible por 4.", argv[1]);
        }
        
        // Se espera al proceso hijo para que no quede en modo zombie
        wait(pid);
        
    }
    
    printf("\n\n");
    
    return (0);
    
}