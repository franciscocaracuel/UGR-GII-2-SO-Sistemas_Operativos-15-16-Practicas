////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
//
// Sistemas Operativos. 2º. Curso 2015/2016
//
// Ejercicio 4. Módulo 2. Sesión 3.
////////////////////////////////////////////////////////////////////////////////

#include <stdlib.h> // Para el exit y para pid_t
#include <errno.h> // Para utilizar la salida de error
#include <sys/types.h> 
#include <unistd.h>
#include <stdio.h> // Para utilizar printf
#include <sys/wait.h>

////////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char* argv[]){
     
    // Se guardará el pid del hijo
    pid_t pid;
    
    int numChilds, nProcs = numChilds = 5;
    
    //pid_t pids[nProcs];
    int status;

    // Se crean todos los hijos
    for(unsigned int i=0; i<nProcs; i++){
        
        if((pid=fork())<0){
            
            printf("\nSe ha producido un error al crear el hijo %d\n", i);
            perror("Error al crear un hijo");
            exit(-1);
            
        // Proceso hijo
        }else if(!pid){
                        
            printf("\n%d: Soy el hijo %d de %d\n", i, getpid(), getppid()); 
            
            //pids[i] = getpid();
                        
            // Se esperan 2 segundos antes de terminar
            sleep(2);
            
            exit(-1);
            
        }
        
    }
    
    pid_t cPid;
    
    // Se espera a todos los hijos
    while ((cPid = wait(&status)) > 0){
        
        printf("\nAcaba de finalizar mi hijo con pid: %d\n", cPid);
        
        numChilds--;
        
        if(numChilds!=0)
            printf("\nSolo me quedan %d hijos vivos\n", numChilds);
        else
            printf("\nNo tengo hijos ejecutándose :_(\n");
        
    }
    
    printf("\n");
    
    return (0);
    
}