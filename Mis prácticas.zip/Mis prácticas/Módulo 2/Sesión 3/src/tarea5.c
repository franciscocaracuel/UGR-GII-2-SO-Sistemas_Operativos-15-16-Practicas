//tarea5.c
//Trabajo con llamadas al sistema del Subsistema de Procesos conforme a POSIX 2.10

#include<sys/types.h>	
#include<sys/wait.h>	
#include<unistd.h>
#include<stdio.h>
#include<errno.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    
    pid_t pid;
    int estado;

    // Lanza un hijo    
    if ((pid = fork()) < 0) {
        perror("\nError en el fork");
        exit(-1);
        
    // Código que ejecuta el hijo
    } else if (pid == 0) {
        
        // El hijo va a ejecutar el comando ldd, que se encuentra en /usr/bin/ldd,
        // como segundo parámetro se escribe el nombre del comando/programa
        // y como tercer parámetro el argumento (o los que necesite el programa
        // como sucesión de parámetros)
        // Le faltaba a execl el último parámetro como un puntero de NULL
        if ((execl("/usr/bin/ldd", "ldd", "./tarea5", NULL) < 0)) {
            perror("\nError en el execl");
            exit(-1);
        }
    }
    
    // Espera el resultado del proceso hijo
    wait(&estado);

    /*
    <estado> mantiene información codificada a nivel de bit sobre el motivo de
    finalización del proceso hijo que puede ser el número de señal o 0 si alcanzó su
    finalización normalmente.
    Mediante la variable estado de wait(), el proceso padre recupera el valor
    especificado por el proceso hijo como argumento de la llamada exit(), pero
    desplazado 1 byte porque el sistema incluye en el byte menos significativo el
    código de la señal que puede estar asociada a la terminación del hijo. Por eso se
    utiliza estado>>8 de forma que obtenemos el valor del argumento del exit() del
    hijo.
     */

    printf("\nMi hijo %d ha finalizado con el estado %d\n", pid, estado);

    exit(0);

}
