///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º Grado Ingeniería Informática
// Curso 2015-2016
//
// --
//
// Ejercicio 2. Sesión 5. Módulo 2
//
///////////////////////////////////////////////////////////////////////////////

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>

///////////////////////////////////////////////////////////////////////////////
// Manejador de señales
//
static void signalHandler(int signal){
    
    char *vez;
    
    static int count[31] = {0};
    
    count[signal]++;
        
    if(count[signal]==1){
        vez = "vez";
    } else{
        vez = "veces";
    }
    
    printf("\n\nLa señal %d se ha recibido %d %s\n\n", signal, count[signal], vez);
    
}

///////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char** argv){
    
    // No se permite el buffer para que aparezcan todos los printf al momento
    if(setvbuf(stdout, NULL, _IONBF, 0)){
        printf("\nError en setvbuf\n");
    }
    
    // struct para controlar las señales de los procesos
    struct sigaction signalAction;
    
    // Se inicializa la estructura con el manejador creado
    signalAction.sa_handler = signalHandler;
    
    // Se inicializa el conjunto de señales con estado vacío
    sigemptyset(&signalAction.sa_mask);
    signalAction.sa_flags = 0;
    
    // Las señales van desde 1 hasta 31
    unsigned int i = 1;
    while(i<=31){
        
        if(sigaction(i, &signalAction, NULL) < 0){
            printf("\nNo puedo manejar la señal %d.\n", i);
            //perror("\nError al intentar establecer el manejador\n");
        }
        
        i++;
        
    }
  
    printf("\nEsperando el envío de señales...\n\n");
    
    while(1){
        
    }
    
    return 0;
    
}