///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º Grado Ingeniería Informática
// Curso 2015-2016
//
// --
//
// Ejercicio 3. Sesión 5. Módulo 2
//
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <signal.h>

///////////////////////////////////////////////////////////////////////////////
// main
//

int main(int argc, char** argv) {

    // Se crea una nueva máscara

    sigset_t new_mask;
    
    // Se inicializa la nueva máscara de señales con todas activas
    sigfillset(&new_mask);
    
    // Se elimina la señal SIGUSR1
    sigdelset(&new_mask, SIGUSR1);
    
    printf("\n\nSe espera a la señal SIGUSR1. Se suspende el proceso...\n\n");
    
    // Se espera solo a la señal SIGUSR1
    sigsuspend(&new_mask);

}