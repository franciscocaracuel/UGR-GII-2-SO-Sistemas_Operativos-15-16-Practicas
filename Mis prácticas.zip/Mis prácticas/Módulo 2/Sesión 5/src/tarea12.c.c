// tarea12.c

#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static int signal_recibida = 0;

// Cuando el proceso recibe la señal SIGTERM, pone signal_recibida a 1, así,
// cuando termina la ejecución comprueba el valor y si es 1, muestra un mensaje
static void manejador(int sig) {
    signal_recibida = 1;
}

int main(int argc, char *argv[]) {

    // Dos tipos de máscaras
    sigset_t conjunto_mascaras;
    sigset_t conj_mascaras_original;
    
    // Estructura de señales
    struct sigaction act;
    
    //Iniciamos a 0 todos los elementos de la estructura act 
    memset(&act, 0, sizeof (act));

    // Se le asigna a la estructura de señales el manejador que se ha creado
    act.sa_handler = manejador;

    // Se le asigna a la señal SIGTERM el manejador creado anteriormente
    if (sigaction(SIGTERM, &act, 0)) {
        perror("sigaction");
        return 1;
    }

    // Iniciamos un nuevo conjunto de mascaras que estará vacío
    sigemptyset(&conjunto_mascaras);
    
    // Añadimos SIGTERM al conjunto de mascaras
    sigaddset(&conjunto_mascaras, SIGTERM);

    // Se cambia la máscara de señales, indicando que el conjunto de señales
    // bloqueadas es el conjunto entre las actuales y conjunto_mascaras
    // Esto significa que si este proceso recibe la señal SIGTERM, lo único
    // que hará será poner la variable globar signal_recibida a 1.
    if (sigprocmask(SIG_BLOCK, &conjunto_mascaras, &conj_mascaras_original) < 0) {
        perror("primer sigprocmask");
        return 1;
    }

    sleep(10);

    // Se restaura la máscara de señales bloqueadas al estado original
    if (sigprocmask(SIG_SETMASK, &conj_mascaras_original, NULL) < 0) {
        perror("segundo sigprocmask");
        return 1;
    }

    sleep(1);

    // Si se ha enviado una señal SIGTERM al proceso durante el tiempo que ha
    // estado durmiendo durante 10 segundos, mostrará el mensaje.
    if (signal_recibida)
        printf("\nSeñal recibida\n");
    return 0;

}
