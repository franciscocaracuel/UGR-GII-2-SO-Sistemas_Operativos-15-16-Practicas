///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// Grado en Ingeniería Informática
// 2015-2016
//
// Ejercicio 2, Actividad 1, Sesión 1, Módulo 2
//
///////////////////////////////////////////////////////////////////////////////

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  	
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

///////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char *argv[]){

	const int SIZE_READ = 80;

	char *path;
	
	char text[SIZE_READ], blockText[50];
	
	int fdRead, fdWrite;
	
	int finalLength, i = 1;

	// Se comprueba si el programa recibe el pathname como argumento
	if(argc==2){
	
		// Se copia en text el pathname
		path = argv[1];
	
	} else{
		path = malloc(sizeof(char) * 128);
		scanf("%s", path);
	}
	
	// Se abre el fichero que se ha especificado. Si ha habido algún error se cierra
	if((fdRead=open(path, O_RDONLY))<0){
		printf("\nError %d al hacer OPEN del fichero de entrada", fdRead);
		perror("Error al hacer OPEN del fichero de entrada\n\n");
		exit(-1);
	}
	
	// Si se ha podido abrir el fichero anterior, se crea uno nuevo para volcar los datos
	if((fdWrite=open("salidaP1-2.txt", O_CREAT|O_WRONLY|O_TRUNC))<0){
		printf("\nError %d al hacer OPEN del fichero de salida", fdWrite);
		perror("Error al hacer OPEN del fichero de salida\n\n");
		exit(-2);
	}
	
	// Se reserva espacio en el fichero para introducir el total de bloques
	lseek(fdWrite, 30, SEEK_SET);
	
	// Se irá escribiendo en el fichero de salida hasta que no haya más datos
	while((finalLength=read(fdRead, text, SIZE_READ)) == SIZE_READ){
		sprintf(blockText, "\n\nBloque %d\n\n", i);
		write(fdWrite, blockText, strlen(blockText));
		write(fdWrite, text, SIZE_READ);
		i++;
	}
	
	// La última parte del archivo que ocupa menos de 80 bytes también hay que mostrarla
	sprintf(blockText, "\n\nBloque %d\n\n", i);
	write(fdWrite, blockText, strlen(blockText));
	write(fdWrite, text, finalLength);
	
	// Se pone al inicio del archivo el número total de bloques
	if(lseek(fdWrite, 0, SEEK_SET) < 0){
		perror("\nError en lseek");
		exit(-3);
	}	
	
	// Se escribe al principio el número de bloques total
	sprintf(blockText, "\n\nEl número de bloques es %d\n\n", i);
	write(fdWrite, blockText, strlen(blockText));
	
	// Se cierran los archivos
	close(fdRead);
	close(fdWrite);

	return EXIT_SUCCESS;

}
