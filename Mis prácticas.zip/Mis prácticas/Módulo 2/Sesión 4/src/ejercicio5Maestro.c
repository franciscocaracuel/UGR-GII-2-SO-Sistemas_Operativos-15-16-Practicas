///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
//
// Curso 2015-2016
//
// Sistemas Operativos - Grado En Ingeniería Informática
//
// --
//
// ejercicio5Maestro.c
///////////////////////////////////////////////////////////////////////////////

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

///////////////////////////////////////////////////////////////////////////////
// main
int main(int argc, char **argv){
    
    // Se comprueban los argumentos
    if (argc!=3){
        printf("\nDebes introducir 2 argumentos. Uso: %s <inicio intervalo> <fin intervalo>\n\n", argv[0]);
        perror("Error al llamar al programa");
        exit (-1);
    }
    
    // Se usarán para enviar los parámetros por execl
    char str1[32], str2[32];
    
    // Se guardan los valores del intervalo
    int less = atoi(argv[1]);
    int higher = atoi(argv[2]);
    
    // Si alguno es negativo se iguala a 1
    if(less<1)
        less = 1;
    
    if(higher<1)
        higher = 1;
    
    // Si el primero es mayor que el segundo se intercambian
    if(less > higher){
        int aux = less;
        less = higher;
        higher = aux;
    }
    
    // Se calcula el elemento intermedio del rango
    int middle = (higher-less)/2 + less;
    
    // Vectores con los dos flujos para los dos hijos
    int fd1[2], fd2[2];
    pid_t PID1, PID2;

    // Se crean dos pipes
    pipe(fd1);
    pipe(fd2);

    // Se ejecuta fork para crear un hijo
    if ((PID1 = fork()) < 0) {
        perror("Error en fork");
        exit(-1);
    }
    
    // Proceso hijo1
    if (PID1 == 0) {
        
        // Se convierten los valors a string para poder pasarlos por argumento
        sprintf(str1, "%d", less);
        sprintf(str2, "%d", middle);
                
        // Se cierra el descriptor de lectura para el hijo
        close(fd1[0]);

        // Se duplica el descriptor de escritura en la salida estándar
        dup2(fd1[1], STDOUT_FILENO);
        
        // Se ejecuta con el primer hijo la primera parte del rango
        execl("/home/fran/Escritorio/Sesión 4/src/ejercicio5Esclavo", "ejercicio5Esclavo", str1, str2, NULL);
              
    // Proceso padre
    } else {
        
        // Se ejecuta fork para crear otro hijo
        if ((PID2 = fork()) < 0) {
            perror("Error en fork");
            exit(-1);
        }

        // Proceso hijo2
        if (PID2 == 0) {
            
            // Se convierten los valors a string para poder pasarlos por argumento
            sprintf(str1, "%d", middle+1);
            sprintf(str2, "%d", higher);

            // Se cierra el descriptor de lectura para el hijo
            close(fd2[0]);

            // Se duplica el descriptor de escritura en la salida estándar
            dup2(fd2[1], STDOUT_FILENO);
            
            // Se ejecuta con el segundo hijo, la segunda parte del rango
            execl("/home/fran/Escritorio/Sesión 4/src/ejercicio5Esclavo", "ejercicio5Esclavo", str1, str2, NULL);

        // Proceso padre
        } else{
            
            // Se cierra el descriptor de escritura para el padre
            close(fd1[1]);
            close(fd2[1]);

            char buffer;

            // Se leen los resultados que ha generado el primer hijo
            while (read(fd1[0], &buffer, sizeof(char)) != 0) {
                printf("%c", buffer);
            } 
            
            // Se leen los resultados que ha generado el segundo hijo
            while (read(fd2[0], &buffer, sizeof(char)) != 0) {
                printf("%c", buffer);
            } 
            
        }
        
    }
    
    return 0;
    
}