///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
//
// Curso 2015-2016
//
// Sistemas Operativos - Grado En Ingeniería Informática
//
// --
//
// ejercicio5Esclavo.c
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h> // Para printf
#include <stdlib.h> // Para exit y atoi
#include <math.h> // sqrt
#include <unistd.h>
#include <errno.h>

///////////////////////////////////////////////////////////////////////////////
// main
int main(int argc, char **argv){
    
    // Se comprueban los argumentos
    if (argc!=3){
        printf("\nDebes introducir 2 argumentos. Uso: %s <inicio intervalo> <fin intervalo>\n\n", argv[0]);
        perror("Error al llamar al programa");
        exit (-1);
    }
    
    // Se guardan los valores del intervalo
    int less = atoi(argv[1]);
    int higher = atoi(argv[2]);
    
    // Si el primero es mayor que el segundo se intercambian
    if(less > higher){
        int aux = less;
        less = higher;
        higher = aux;
    }
    
    // Contador
    int i = less;
    int prime;
    
    while(i<=higher){
        
        // Es primo si 2<j<=sqrt(i)
        prime = 1;
        
        int j = 2;
        
        // Mientras que no sea primo buscara
        while(prime && j<=sqrt(i)){
            
            // Se comprueba si es divisible por todos los número del rango
            if(i%j==0)
                prime = 0;
            
            j++;
            
        }
        
        if(prime)
            printf("%d\n", i);
        
        i++;
        
    }
    
    return 0;
    
}