///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º. Sistemas Operativos. Curso 2015/2016
//
// Ejercicio 2. Sesión 2. Módulo 2
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>

///////////////////////////////////////////////////////////////////////////////
// Muestra por pantalla los permisos que recibe
//
void showPermisos(__mode_t perm){
    
    printf((S_ISDIR(perm)) ? "d" : "-");
    printf((perm & S_IRUSR) ? "r" : "-");
    printf((perm & S_IWUSR) ? "w" : "-");
    printf((perm & S_IXUSR) ? "x" : "-");
    printf((perm & S_IRGRP) ? "r" : "-");
    printf((perm & S_IWGRP) ? "w" : "-");
    printf((perm & S_IXGRP) ? "x" : "-");
    printf((perm & S_IROTH) ? "r" : "-");
    printf((perm & S_IWOTH) ? "w" : "-");
    printf((perm & S_IXOTH) ? "x" : "-");

}

///////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char** argv) {
    
    // Si no llegan todos los argumentos se termina la ejecución del proceso
    if(argc != 3){
        printf("\nDebes introducir 2 parámetros. Ej: ./ejercicio02 \"pathname\" "
                "\"permisos\"\n\n");
        perror("\nError con el formato\n");
        exit (1);
    }
    
    struct stat atributos;
    
    if(lstat(argv[1], &atributos) < 0){
        printf("\nError al acceder a los atributos de %s\n", argv[1]);
        perror("\nError en lstat\n");
        exit (2);
    } else if(!S_ISDIR(atributos.st_mode)){
        printf("\nError. El elemento que se %s no es un directorio\n", argv[1]);
        perror("\nError al leer el directorio\n");
        exit (3);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Llegados a este punto se sabe que el argumento que se recibe es un 
    // directorio
    
    // Se convierte el segundo parámetro con los permisos en long 
    long perm = strtol(argv[2], 0, 8);
    
    // Se abre el directorio que se recibe
    DIR *dir = opendir(argv[1]);
    
    // Aquí se guardará el contenido de cada directoio
    struct dirent *drt;
    
    // opendir devuelve un puntero de tipo DIR que es nulo en caso de que no
    // pueda abrir el directorio que recibe
    if(dir == NULL){
        printf("\nError. No se puede abrir el directorio %s\n", argv[1]);
        perror("\nError al abrir el directorio\n");
        exit (4);
    }
    
    // Se recorren todos los ficheros del directorio
    while((drt = readdir(dir)) != NULL){
        
        // Se utiliza para guardar los permisos antiguos
        __mode_t permAntiguos;

        // Se hace para todos los ficheros menos para la carpeta actual y 
        // el padre
        if (strcmp(drt->d_name, ".")!=0 && strcmp(drt->d_name, "..")!=0) {

            // Se recogen los atributos del fichero en atributos
            if (lstat(drt->d_name, &atributos) >= 0) {

                // Se guardan los permisos antiguos para mostrarlos
                permAntiguos = atributos.st_mode;
                
                int nerr;

                // Se establecen los parámetros que se reciben como argumento
                if ((nerr = chmod(drt->d_name, perm)) < 0) {
                    printf("%s : %i", drt->d_name, nerr);
                    showPermisos(permAntiguos);
                    perror("\nError en chmod para archivo\n");
                    exit(-1);
                } else{
                    
                    // Se muestra el nombre del fichero
                    printf("\n%s : ", drt->d_name);
                    
                    // Se muestran los permisos antiguos
                    showPermisos(permAntiguos);
                    
                    printf(" ");
                    
                    // Se muestran los permisos nuevos
                    showPermisos(perm);
                    
                }
                
                printf("\n");

            }

        }

    }
    
    printf("\n");
    
    // Se cierrra el directorio
    closedir(dir);

    return (EXIT_SUCCESS);
    
}

