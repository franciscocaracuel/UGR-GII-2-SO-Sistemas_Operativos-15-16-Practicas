/*
tarea3.c
Trabajo con llamadas al sistema del Sistema de Archivos ''POSIX 2.10 compliant''
Este programa fuente est� pensado para que se cree primero un programa con la parte
 de CREACION DE ARCHIVOS y se haga un ls -l para fijarnos en los permisos y entender
 la llamada umask.
En segundo lugar (una vez creados los archivos) hay que crear un segundo programa
 con la parte de CAMBIO DE PERMISOS para comprender el cambio de permisos relativo
 a los permisos que actualmente tiene un archivo frente a un establecimiento de permisos
 absoluto.
 */

#include<sys/types.h>	//Primitive system data types for abstraction of implementation-dependent data types.
//POSIX Standard: 2.6 Primitive System Data Types <sys/types.h>
#include<unistd.h>		//POSIX Standard: 2.10 Symbolic Constants         <unistd.h>
#include<sys/stat.h>
#include<fcntl.h>		//Needed for open
#include<stdio.h>
#include<errno.h>

///////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char *argv[]) {

    int fd1, fd2;
    struct stat atributos;

    // CREACION DE ARCHIVOS
    // Abre el archivo1 solo para escritura y elimina su contenido, si no existe lo crea
    // Se establecen permisos de lectura, escritura y ejecución para el grupo
    if ((fd1 = open("archivo1", O_CREAT | O_TRUNC | O_WRONLY, S_IRGRP | S_IWGRP | S_IXGRP)) < 0) {
        printf("\nError %d en open(archivo1,...)", errno);
        perror("\nError en open");
        return(-1);
    }

    // umask resta los permisos que ya se tiene en el sistema con los que recibe
    // por parámetro. En este caso al poner 0, lo deja como estaba
    umask(0);
    
    // Crea otro archivo igual que archivo1
    if ((fd2 = open("archivo2", O_CREAT | O_TRUNC | O_WRONLY, S_IRGRP | S_IWGRP | S_IXGRP)) < 0) {
        printf("\nError %d en open(archivo2,...)", errno);
        perror("\nError en open");
        return(-1);
    }

    //CAMBIO DE PERMISOS
    // Se recogen los atributos que tiene archivo1. Si hay fallo el recogerlos
    // se termina el programa
    if (stat("archivo1", &atributos) < 0) {
        printf("\nError al intentar acceder a los atributos de archivo1");
        perror("\nError en lstat");
        return(-1);
    }
    
    // Le quita al programa el permiso de ejecución al grupo y asigna el bit
    // de grupo
    if (chmod("archivo1", (atributos.st_mode & ~S_IXGRP) | S_ISGID) < 0) {
        perror("\nError en chmod para archivo1");
        return(-1);
    }
    
    // Establece permisos de lectura, escritura y ejecución para el propietario (S_IRWXU)
    // El grupo tiene permiso de lectura (S_IRGRP)
    // El grupo tiene permiso de escritura (S_IWGRP))
    // El resto tiene permisos de lectura (S_IROTH)
    if (chmod("archivo2", S_IRWXU | S_IRGRP | S_IWGRP | S_IROTH) < 0) {
        perror("\nError en chmod para archivo2");
        return(-1);
    }

    return 0;
    
}
