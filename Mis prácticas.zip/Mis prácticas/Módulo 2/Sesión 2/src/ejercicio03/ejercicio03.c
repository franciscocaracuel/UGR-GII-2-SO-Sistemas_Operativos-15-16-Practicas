///////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// 2º. Sistemas Operativos. Curso 2015/2016
//
// Ejercicio 3. Sesión 2. Módulo 2
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>

int countReg = 0;
long countSize = 0;

///////////////////////////////////////////////////////////////////////////////
// Recorre un directorio
//
void showDir(const char *name){
        
    //printf("\n\nEntra a un directorio: %s\n\n", name);

    struct stat atributos;
    
    // Se abre el directorio que se recibe
    DIR *dir = opendir(name);
       
    // opendir devuelve un puntero de tipo DIR que es nulo en caso de que no
    // pueda abrir el directorio que recibe
    if(dir == NULL){
        printf("\nError. No se puede abrir el directorio %s\n", name);
        perror("\nError al abrir el directorio\n");
        exit (4);
    }
         
    // Aquí se guardará el contenido de cada directoio
    struct dirent *drt;
    
    // Se recorren todos los ficheros del directorio
    while((drt = readdir(dir)) != NULL) {
        
        // Se copia en path la ruta completa
        char path[512];        
        sprintf(path, "%s/%s", name, drt->d_name) ;
        
        //printf("\n\n%s\n\n", path);
        
        // Se hace para todos los ficheros menos para la carpeta actual y 
        // el padre
        if (strcmp(drt->d_name, ".") != 0 && strcmp(drt->d_name, "..") != 0) {
                    
            int nerr;
            
            // Se recogen los atributos del fichero en atributos
            if ((nerr = lstat(path, &atributos)) >= 0) {
            
                if (S_ISDIR(atributos.st_mode)) {
                    //printf("\nSe encuentra un directorio llamado: %s\n", path);
                    showDir(path);
                } else if (S_ISREG(atributos.st_mode) && (atributos.st_mode & S_IXGRP)
                        && (atributos.st_mode & S_IXOTH)) {
       
                    countReg++;
                    countSize += atributos.st_size;
                    printf("%s %ld\n", drt->d_name, drt->d_ino);
                }

            } else{
                printf("\nError %i con %s\n", nerr, drt->d_name);
            }

        }

    }
    
    // Se cierrra el directorio
    closedir(dir);

}

///////////////////////////////////////////////////////////////////////////////
// main
//
int main(int argc, char** argv) {
    
    char path[512];
    
    // Si no llegan todos los argumentos se termina la ejecución del proceso
    if(argc > 2){
        printf("\nDebes introducir 1 parámetro o ninguno. Ej: ./ejercicio02 [\"pathname\"]\n\n");
        perror("\nError con el formato\n");
        exit (1);
    } else if(argc == 2){
        
        strcpy(path, argv[1]);
        
    } else if(argc ==1){
        
        strcpy(path, ".");
        
    }
    
    struct stat atributos;
    
    if(lstat(path, &atributos) < 0){
        printf("\nError al acceder a los atributos de %s\n", argv[1]);
        perror("\nError en lstat\n");
        exit (2);
    } else if(!S_ISDIR(atributos.st_mode)){
        printf("\nError. El elemento que se %s no es un directorio\n", argv[1]);
        perror("\nError al leer el directorio\n");
        exit (3);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Llegados a este punto se sabe que el argumento que se recibe es un 
    // directorio
            
    printf("\n");
    
    printf("\nLos i-nodos son:\n\n");
    
    showDir(path);
        
    printf("\nExisten %d archivos regulares con permiso x para grupo y otros\n", countReg);
    
    printf("\nEl tamaño total ocupado por dichos archivos es %ld bytes\n\n", countSize);
    
    return (EXIT_SUCCESS);
    
}
