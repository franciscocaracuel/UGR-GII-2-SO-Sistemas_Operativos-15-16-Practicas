////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// Sistemas Operativos. 2º G I.I. B3. 2015-2016
//
// Sesión 7. Módulo 2.
//
// servidor.c
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

#define tamano 1024
#define longnombre 50

// Manejador de senal (SIGPIPE) para cuando se escribe en FIFO no abierto aun 
// para lectura, por defecto esta senal terminaria el proceso.

static void mimanejador(int senal) {
    int estado;
    wait(&estado);
}

main(int argc, char **argv) {

    int pid, dfifoe, dfifos, dbloqueo, dproxy;
    char nombrefifoe[longnombre], nombrefifos[longnombre], buffer[tamano], proxy[longnombre];
    size_t leido;
    const char* nombreBloqueo = "bloqueo";

    setbuf(stdout, NULL);

    if (argc != 2) {
        printf("Servidor: Formato: servidor <nombre_fifo>\n");
        exit(1);
    }

    // Se establece la máscara por defecto
    umask(0);

    // Compone los nombres de los FIFOs conocidos a partir del parametro,
    // uno de entrada y otro de salida (desde el punto de vista del servidor).
    sprintf(nombrefifoe, "%se", argv[1]);
    sprintf(nombrefifos, "%ss", argv[1]);

    // Si existiesen los archivos, se borran para no entrar en conflicto
    unlink(nombrefifoe);
    unlink(nombrefifos);

    // Pone el manejador para la senal SIGCHLD
    if (signal(SIGCHLD, mimanejador) == SIG_ERR)
        perror("Servidor: Error configurando la señal");

    // Se crea el cauce de entrada
    if (mkfifo(nombrefifoe, S_IRWXU) < 0) {
        perror("Servidor: Problema con el archivo fifo de entrada al servidor");
        exit(2);
    }

    // Se abre el cauce de entrada
    if ((dfifoe = open(nombrefifoe, O_RDWR)) < 0) {
        perror("Servidor: Problema con el archivo fifo de entrada al servidor");
        exit(3);
    }

    // Se crea el cauce de salida    
    if (mkfifo(nombrefifos, S_IRWXU) < 0) {
        perror("Servidor: Problema con el archivo fifo de salida del servidor");
        exit(4);
    }

    // Se abre el cauce de salida
    if ((dfifos = open(nombrefifos, O_RDWR)) < 0) {
        perror("Servidor: Problema con el archivo fifo de salida del servidor");
        exit(5);
    }
    
    // Creación del fichero que se utiliza como cerrojo
    if((dbloqueo=open(nombreBloqueo, O_CREAT, 0666))<0){
        printf("Servidor: Error creando el fichero de bloqueo");
        exit(10);
    }

    // Comienza la ejecución "infinita" del servidor
    while((leido = read(dfifoe, &buffer, tamano)) != 0) {

        printf("\nCliente intentando conectar\n");

        // Error al crear el proceso hijo
        if ((pid = fork()) < 0) {
            perror("Error al crear el proceso hijo");
            exit(EXIT_FAILURE);
        // Proceso hijo
        } else if (pid == 0) {

            // Se guarda el pid del hijo
            pid = getpid();
            
            sprintf(proxy, "proxy-%d", pid);

            // El proxy creará el fifo
            if (mkfifo(proxy, S_IRWXU) < 0) {
                perror("Servidor: Problema con el archivo fifo del proxy");
                exit(6);
            }

            printf("Pid Proxy:%d enviado", pid);
            
            // El cliente recibe el pid para comunicarse por el proxy. Si al 
            // enviar no se recibe la misma cantidad de bytes que se envía ha
            // habido algún error            
            if (write(dfifos, &pid, sizeof(pid)) != sizeof(pid)) {
                perror("Servidor: Problema con la comunicación con el cliente");
                exit(7);
            }

            // Se abre el fifo creado con el que se comunica con el cliente
            if ((dproxy = open(proxy, O_RDONLY)) < 0) {
                perror("Servidor: Problema al crear el archivo de comunicación");
                exit(8);
            }

            // El proxy leerá directamente del archivo fifo creado
            dup2(dproxy, STDIN_FILENO);

            // Se ejecuta el proxy que ejecuta el resto del codigo
            if(execlp("./proxy", "proxy", NULL) < 0){
                perror("Servidor: Problema al lanzar el proxy");
                exit(9);
            }

        }

    }

    // El proceso original elimina zombies ya que es el padre.
    //while (wait(&estado) != -1);
    exit(0);
}



