////////////////////////////////////////////////////////////////////////////////
// Francisco Javier Caracuel Beltrán
// Sistemas Operativos. 2º G I.I. B3. 2015-2016
//
// Sesión 7. Módulo 2.
//
// proxy.c
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h> 

//Constantes
#define tamano 1024
#define longnombre 50

int main(int argc, char* argv[]) {

    char buffer[tamano], nombrefifo[longnombre];
    FILE* dtemporal;
    size_t leido;
    int dbloqueo;
    const char* nombreBloqueo = "bloqueo";
            
    // Se crea el archivo temporal
    if ((dtemporal = tmpfile()) == NULL) {
        perror("Proxy: Error al crear el archivo temporal");
        exit(2);
    }

    // Lee en la entrada estándar, que es el fichero fifo creado anteriormente
    while ((leido = read(STDIN_FILENO, &buffer, tamano)) > 0) {
        
        // Escribe en el archivo temporal los datos recibidos del cliente
        if (fwrite(buffer, sizeof(char), leido, dtemporal) != leido) {
            perror("Proxy: Error al escribir en el fichero temporal");
            exit(3);
        }
    }
    
    // Se establece de nuevo el inicio del fichero
    //rewind(dtemporal);

    // Llegados a este punto ya se tiene el archivo temporal completamente
    // escrito y es cuando se bloquea la pantalla para mostrar los datos
    
    // Se abre el archivo que se usará para simular la exclusión mutua
    if ((dbloqueo = open(nombreBloqueo, O_RDWR)) < 0) {
        perror("Proxy: Error con el cerrojo");
        exit(1);
    }
    
    // Se establecen los datos del cerrojo
    struct flock cerrojo;

    // Se inicializan los datos para crear el cerrojo
    cerrojo.l_type = F_WRLCK;
    cerrojo.l_whence = SEEK_SET;
    cerrojo.l_start = 0;
    cerrojo.l_len = 0;

    // Se establece el cerrojo
    if (fcntl(dbloqueo, F_SETLKW, &cerrojo) == -1) {
        perror("Proxy: problemas al bloquear para impresion");
        exit(4);
    }
  
    // Se escriben todos los datos en la pantalla
    while ((leido = fread(buffer, sizeof(char), tamano, dtemporal)) > 0) {
        printf("%s", buffer);
    }

    // Se quita el cerrojo
    cerrojo.l_type = F_UNLCK;
    
    if (fcntl(dbloqueo, F_SETLKW, &cerrojo) == -1) {
        perror("Proxy: problemas al desbloquear de impresion");
        exit(5);
    }
    
    // Se cierra el fichero temporal. Se elimina automáticamente
    fclose(dtemporal);

    //Eliminamos el archivo fifo antes creado
    sprintf(nombrefifo, "proxy-%d", getpid());
    unlink(nombrefifo);

    exit(EXIT_SUCCESS);

}

